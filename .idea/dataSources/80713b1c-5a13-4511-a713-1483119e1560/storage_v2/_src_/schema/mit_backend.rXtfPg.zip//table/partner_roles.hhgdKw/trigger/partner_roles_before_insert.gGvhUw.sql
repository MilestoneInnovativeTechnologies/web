create trigger partner_roles_before_insert
  before INSERT
  on partner_roles
  for each row
  BEGIN
				DECLARE V_PARTNER CHAR(15);
				DECLARE ROLENAME VARCHAR(100);
				SELECT partner INTO V_PARTNER FROM partner_logins WHERE id = NEW.login;
				SELECT name INTO ROLENAME FROM roles WHERE code = NEW.role;
				SET NEW.partner = V_PARTNER;
				SET NEW.rolename = ROLENAME;
			END;

