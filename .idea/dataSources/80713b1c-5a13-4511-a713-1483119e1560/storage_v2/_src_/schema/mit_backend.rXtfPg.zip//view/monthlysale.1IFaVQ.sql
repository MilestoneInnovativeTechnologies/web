create view monthlysale as
  select
    monthname(`mit_backend`.`customer_registrations`.`registered_on`)                                             AS `Month`,
    `mit_backend`.`customer_registrations`.`registered_on`                                                        AS `Date`,
    (select `mit_backend`.`partners`.`name`
     from `mit_backend`.`partners`
     where (`mit_backend`.`partners`.`code` =
            `mit_backend`.`customer_registrations`.`customer`))                                                   AS `Customer`,
    (select `p`.`name`
     from (`mit_backend`.`partners` `p`
       join `mit_backend`.`partner_relations` `r`)
     where ((`p`.`code` = `r`.`parent`) and (`r`.`partner` =
                                             `mit_backend`.`customer_registrations`.`customer`)))                 AS `Distributor`,
    (select `mit_backend`.`products`.`name`
     from `mit_backend`.`products`
     where (`mit_backend`.`products`.`code` =
            `mit_backend`.`customer_registrations`.`product`))                                                    AS `Product`,
    (select `mit_backend`.`editions`.`name`
     from `mit_backend`.`editions`
     where (`mit_backend`.`editions`.`code` =
            `mit_backend`.`customer_registrations`.`edition`))                                                    AS `Edition`
  from `mit_backend`.`customer_registrations`
  where (year(`mit_backend`.`customer_registrations`.`registered_on`) = year(now()))
  order by `mit_backend`.`customer_registrations`.`registered_on`;

