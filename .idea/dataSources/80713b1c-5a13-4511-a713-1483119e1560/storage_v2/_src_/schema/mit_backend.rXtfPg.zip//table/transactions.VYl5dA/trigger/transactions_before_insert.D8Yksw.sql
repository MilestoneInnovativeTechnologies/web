create trigger transactions_before_insert
  before INSERT
  on transactions
  for each row
  BEGIN SET NEW.amount = NEW.price * NEW.exchange_rate; END;

