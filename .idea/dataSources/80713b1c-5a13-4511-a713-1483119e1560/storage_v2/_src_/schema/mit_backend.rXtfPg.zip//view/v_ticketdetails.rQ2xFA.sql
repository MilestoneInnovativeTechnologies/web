create view v_ticketdetails as select
                                 `mit_backend`.`ticket_status_trans`.`user` AS `code`,
                                 (case `mit_backend`.`ticket_status_trans`.`status`
                                  when 'opened'
                                    then 1
                                  else 0 end)                               AS `opened`,
                                 (case `mit_backend`.`ticket_status_trans`.`status`
                                  when 'closed'
                                    then 1
                                  else 0 end)                               AS `closed`,
                                 0                                          AS `pending`,
                                 0                                          AS `inprogress`,
                                 0                                          AS `hold`
                               from `mit_backend`.`ticket_status_trans`
                               where ((`mit_backend`.`ticket_status_trans`.`status` in ('opened', 'closed')) and
                                      (cast(`mit_backend`.`ticket_status_trans`.`created_at` as date) =
                                       cast((utc_timestamp() + interval 5.30 hour) as date)))
                               union all select
                                           `mit_backend`.`ticket_current_status`.`user` AS `code`,
                                           0                                            AS `opened`,
                                           0                                            AS `closed`,
                                           sum((case `mit_backend`.`ticket_current_status`.`status`
                                                when 'opened'
                                                  then 1
                                                else 0 end))                            AS `pending`,
                                           sum((case `mit_backend`.`ticket_current_status`.`status`
                                                when 'inprogress'
                                                  then 1
                                                else 0 end))                            AS `inprogress`,
                                           sum((case `mit_backend`.`ticket_current_status`.`status`
                                                when 'hold'
                                                  then 1
                                                else 0 end))                            AS `hold`
                                         from `mit_backend`.`ticket_current_status`
                                         where (`mit_backend`.`ticket_current_status`.`status` in
                                                ('inprogress', 'hold', 'opened'))
                                         group by `code`;

