create view v_dailyticketstatus as
  select
    `mit_backend`.`v_ticketdetails`.`code`                                                                    AS `code`,
    (select `mit_backend`.`partners`.`name`
     from `mit_backend`.`partners`
     where (`mit_backend`.`partners`.`code` = convert(`mit_backend`.`v_ticketdetails`.`code` using utf8mb4))) AS `name`,
    sum(
        `mit_backend`.`v_ticketdetails`.`opened`)                                                             AS `opened`,
    sum(
        `mit_backend`.`v_ticketdetails`.`closed`)                                                             AS `closed`,
    sum(
        `mit_backend`.`v_ticketdetails`.`pending`)                                                            AS `pending`,
    sum(
        `mit_backend`.`v_ticketdetails`.`inprogress`)                                                         AS `inprogress`,
    sum(`mit_backend`.`v_ticketdetails`.`hold`)                                                               AS `hold`,
    sum(((`mit_backend`.`v_ticketdetails`.`pending` + `mit_backend`.`v_ticketdetails`.`inprogress`) +
         `mit_backend`.`v_ticketdetails`.`hold`))                                                             AS `total`
  from `mit_backend`.`v_ticketdetails`
  group by `mit_backend`.`v_ticketdetails`.`code`
  order by `total` desc;

